use axum::{
    extract::Path,
    routing::get,
    Router,
    Extension,
    Json,
    http::StatusCode,
};
use serde::{Serialize, Deserialize};
use sqlx::{FromRow, PgPool};
use chrono::NaiveDate; 


#[derive(Serialize, Deserialize, Debug, FromRow)]
pub struct UserData {
    name: String,
    gender: String,
}


pub async fn get_user_by_id(
    Extension(pg_pool): Extension<PgPool>,
    Path(user_id): Path<String>, 
) -> Result<Json<UserData>, (StatusCode, String)> {
    match fetch_user_data_by_id(&pg_pool, &user_id).await {
        Ok(user_data) => Ok(Json(user_data)),
        Err(_) => Err((
            StatusCode::INTERNAL_SERVER_ERROR,
            "Failed to fetch user data".to_string(),
        )),
    }
}


pub async fn fetch_user_data_by_id(pool: &PgPool, user_id: &str) -> Result<UserData, sqlx::Error> {
    let user = sqlx::query_as::<_, UserData>( 
        "SELECT 
            name, 
            gender
            FROM users WHERE user_line_id = $1"
    )
    .bind(user_id)
    .fetch_one(pool)
    .await?;
    
    Ok(user)
}